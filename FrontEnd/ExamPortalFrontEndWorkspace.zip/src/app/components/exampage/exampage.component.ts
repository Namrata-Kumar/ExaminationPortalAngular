import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exampage',
  templateUrl: './exampage.component.html',
  styleUrls: ['./exampage.component.scss']
})
export class ExampageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
