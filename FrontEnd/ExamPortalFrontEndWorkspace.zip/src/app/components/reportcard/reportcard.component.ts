import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportcard',
  templateUrl: './reportcard.component.html',
  styleUrls: ['./reportcard.component.scss']
})
export class ReportcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
