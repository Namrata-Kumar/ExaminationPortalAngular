import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-removequestion',
  templateUrl: './removequestion.component.html',
  styleUrls: ['./removequestion.component.scss']
})
export class RemovequestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
